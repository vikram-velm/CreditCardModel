import UIKit

class Customer {
    let DateOfBirth: String
    let customerName: String
    var creditCards: [CreditCard] = []
    
    init(dob: String, name: String) {
        self.DateOfBirth = dob
        self.customerName = name
    }
    
    deinit {
        print("deinit Customer")
    }
    
    func addCreditCard(creditCard: CreditCard) {
        creditCards.append(creditCard)
    }
    
    func removeCreditCard(creditCard: CreditCard) {
        let isCreditCardAvailable = creditCards.contains { $0.cardNumber == creditCard.cardNumber }
        if isCreditCardAvailable {
            if let index = (self.creditCards.firstIndex { $0 === creditCard }) {
                self.creditCards.remove(at: index)
            }
        }
    }
}

class CreditCard {
    let cardNumber: Int
    let expiryDate: String
    let cvv: Int
    unowned let customer: Customer
    
    init(cardNumber: Int, expiryDate: String, cvv:Int, customer: Customer) {
        self.cardNumber = cardNumber
        self.expiryDate = expiryDate
        self.cvv = cvv
        self.customer = customer
    }
    
    deinit {
       print("deinit creditcard")
    }
}

var customer1 = Customer(dob: "02/12/90", name: "Vikram")
var creditCard1 = CreditCard(cardNumber: 1111, expiryDate: "06/23", cvv: 311, customer: customer1)
var creditCard2 = CreditCard(cardNumber: 1112, expiryDate: "06/24", cvv: 312, customer: customer1)

customer1.addCreditCard(creditCard: creditCard1)
customer1.addCreditCard(creditCard: creditCard2)

var customer2 = Customer(dob: "02/12/91", name: "Raghu")
var creditCard3 = CreditCard(cardNumber: 1111, expiryDate: "06/23", cvv: 311, customer: customer2)
customer2.addCreditCard(creditCard: creditCard3)

customer1.removeCreditCard(creditCard: creditCard2)

print("customer 1 \(customer1.customerName)__\(customer1.DateOfBirth)__\(customer1.creditCards.count)")

print("customer 2 \(customer2.customerName)__\(customer2.DateOfBirth)__\(customer2.creditCards.count)")






